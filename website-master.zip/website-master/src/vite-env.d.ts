/// <reference types="vite/client" />
/// <reference types="vite-plugin-svgr/client" />
/// <reference types="@titaniumnetwork-dev/ultraviolet/client" />
